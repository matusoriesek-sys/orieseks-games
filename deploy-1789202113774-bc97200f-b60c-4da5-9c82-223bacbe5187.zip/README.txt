THE ORIEŠEKS GAMES — appka na vlastnú doménu / na plochu telefónu
=================================================================

Toto NIE JE jedna hra, ale celá herňa: úvodná obrazovka s dlaždicami hier.
Teraz je v nej hrateľný Prípad strieborného vlka, ďalšie pribudnú do rovnakej
appky — deti nemusia nič preinštalovať, nová hra sa im objaví sama.

Čo je v priečinku
-----------------
index.html               celá appka (herňa + hry), jeden súbor
manifest.webmanifest     názov "Oriešeks", ikony, spustenie v režime appky
sw.js                    offline režim (po prvom otvorení funguje aj bez internetu)
icon-*.png, favicon-*    ikony na plochu telefónu a do záložiek (z brand manuálu)
spis.pdf, manual.pdf     tlačená verzia prípadu vlka (sťahuje sa priamo z appky)

Ako to dostať na internet (vyber si jedno)
------------------------------------------
A) Netlify Drop — najrýchlejšie, zadarmo, bez účtu na 24 h
   1. Otvor https://app.netlify.com/drop
   2. Presuň tam CELÝ priečinok "web" (nie zip).
   3. Dostaneš adresu typu https://nieco-nieco.netlify.app — tú pošli deťom.
   4. Ak si spravíš zadarmo účet, adresa ostane natrvalo a dá sa premenovať
      (Site settings → Change site name), prípadne pripojiť vlastnú doménu
      (Domain management → Add custom domain).

B) Vlastná doména, ktorú už máš
   Nahraj obsah priečinka "web" cez FTP do koreňa webu (alebo do /hry/).
   Musí to bežať cez https:// — inak iPhone nedovolí režim appky a offline.

C) GitHub Pages
   Nový repozitár → nahraj súbory → Settings → Pages → Deploy from branch: main / root.

Ako sa appka pridá na plochu iPhonu
-----------------------------------
1. Otvoriť adresu v Safari (musí to byť Safari, nie Chrome).
2. Ťuknúť dole na ikonu Zdieľať (štvorček so šípkou nahor).
3. Vybrať "Pridať na plochu" (Add to Home Screen) → Pridať.
4. Na ploche pribudne ikona "Oriešeks" s logom. Otvorí sa CELÁ appka —
   výber hier, nie iba jedna hra — na celú obrazovku a po prvom spustení
   aj bez internetu.

Na Androide je to v Chrome: menu (tri bodky) → "Pridať na plochu".

Keď pribudne nová hra alebo niečo zmeníme
-----------------------------------------
Stačí nahrať nový index.html a sw.js. Telefóny si novú verziu stiahnu samy
pri druhom otvorení (prvé otvorenie ešte ukáže starú, uloženú verziu).
Ikona na ploche ostáva tá istá.

Poznámka k rebríčku
-------------------
V tejto verzii sa výsledky tímov ukladajú do pamäte konkrétneho telefónu
(každé zariadenie má svoj rebríček). Spoločný rebríček pre všetkých funguje
vo verzii na claude.ai. Keď bude treba spoločný aj na vlastnej doméne,
doplníme k tomu malú databázu.
